package com.example.kiit.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

public class CountryDetails extends AppCompatActivity {

    TextView tvCountryname,tv_Cases,tv_Recovered,tv_Deaths,tv_Critical,tv_Active,tv_TodayDeaths,tv_todayCases;
    private int positionCountry;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_country_details);
        Intent intent = getIntent();
        positionCountry = intent.getIntExtra("position",0);

        getSupportActionBar().setTitle(AffectedCountries.countryModelList.get(positionCountry).getCountry());
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        tvCountryname = findViewById(R.id.countrytv);
        tv_Cases = findViewById(R.id.casestv);
        tv_Deaths = findViewById(R.id.deathstv);
        tv_todayCases = findViewById(R.id.todaycasetv);
        tv_TodayDeaths = findViewById(R.id.todaydeathstv);
        tv_Recovered = findViewById(R.id.recoveretv);
        tv_Critical = findViewById(R.id.criticaltv);
        tv_Active = findViewById(R.id.activetv);

        tvCountryname.setText(AffectedCountries.countryModelList.get(positionCountry).getCountry());
        tv_Cases.setText(AffectedCountries.countryModelList.get(positionCountry).getCases());
        tv_Deaths.setText(AffectedCountries.countryModelList.get(positionCountry).getDeaths());
        tv_Critical.setText(AffectedCountries.countryModelList.get(positionCountry).getCriticalcases());
        tv_TodayDeaths.setText(AffectedCountries.countryModelList.get(positionCountry).getTodaydeaths());
        tv_todayCases.setText(AffectedCountries.countryModelList.get(positionCountry).getTodayCases());
        tv_Active.setText(AffectedCountries.countryModelList.get(positionCountry).getActivecases());
        tv_Recovered.setText(AffectedCountries.countryModelList.get(positionCountry).getRecoveredcases());

    }
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == android.R.id.home)
            finish();
        return super.onOptionsItemSelected(item);
    }
}