package com.example.kiit.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class screening_three extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screening_three);
    }
}