package com.example.kiit.myapplication;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.eazegraph.lib.charts.PieChart;
import org.eazegraph.lib.models.PieModel;
import org.json.JSONException;
import org.json.JSONObject;

public class CoronaCase_details extends AppCompatActivity {
    TextView tvCases,tvRecovered,tvDeaths,tvCritical,tvActive,tvTodayDeaths,tvtodayCases,tvAffectedCountry;
    ScrollView scrollView;
    PieChart pieChart;
    Button trac_btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        tvCases = findViewById(R.id.totalcase_tv);
        tvActive = findViewById(R.id.active_tv);
        tvAffectedCountry = findViewById(R.id.affectedcountries);
        tvCritical = findViewById(R.id.critical_tv);
        tvDeaths = findViewById(R.id.totaldeaths_tv);
        tvTodayDeaths = findViewById(R.id.todaydeaths_tv);
        tvtodayCases = findViewById(R.id.todaycases_tv);
        tvRecovered=findViewById(R.id.recovered_tv);
        trac_btn = findViewById(R.id.btn_track);
        trac_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(CoronaCase_details.this,AffectedCountries.class));
            }
        });

        scrollView = findViewById(R.id.Scroll);
        pieChart = findViewById(R.id.piechart);
        getSupportActionBar().setTitle("Track Cases");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        fetchData();
    }
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == android.R.id.home)
            finish();
        return super.onOptionsItemSelected(item);
    }
    private void fetchData() {
        String url = "https://corona.lmao.ninja/v2/all/";
        StringRequest request = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response.toString());
                            tvCases.setText(jsonObject.getString("cases"));
                            tvActive.setText(jsonObject.getString("active"));
                            tvAffectedCountry.setText(jsonObject.getString("affectedCountries"));
                            tvCritical.setText(jsonObject.getString( "critical"));
                            tvDeaths.setText(jsonObject.getString("deaths"));
                            tvtodayCases.setText(jsonObject.getString("todayCases"));
                            tvTodayDeaths.setText(jsonObject.getString("todayDeaths"));
                            tvRecovered.setText(jsonObject.getString( "recovered"));

                            pieChart.addPieSlice(new PieModel("Cases",Integer.parseInt(tvCases.getText().toString()), Color.parseColor("#FFA726")));
                            pieChart.addPieSlice(new PieModel("Recovered",Integer.parseInt(tvRecovered.getText().toString()), Color.parseColor("#66BB6A")));
                            pieChart.addPieSlice(new PieModel("Deaths",Integer.parseInt(tvDeaths.getText().toString()), Color.parseColor("#EF5350")));
                            pieChart.addPieSlice(new PieModel("Active",Integer.parseInt(tvActive.getText().toString()), Color.parseColor("#29B6F6")));
                            pieChart.startAnimation();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(CoronaCase_details.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(request);
    }
}