package com.example.kiit.myapplication;

public class CountryModel {
    private String flag,country,cases,todayCases,deaths,todaydeaths,recoveredcases,activecases,criticalcases;

    public CountryModel(String flag, String country, String cases, String todayCases, String deaths, String todaydeaths, String recoveredcases, String activecases, String criticalcases) {
        this.flag = flag;
        this.country = country;
        this.cases = cases;
        this.todayCases = todayCases;
        this.deaths = deaths;
        this.todaydeaths = todaydeaths;
        this.recoveredcases = recoveredcases;
        this.activecases = activecases;
        this.criticalcases = criticalcases;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCases() {
        return cases;
    }

    public void setCases(String cases) {
        this.cases = cases;
    }

    public String getTodayCases() {
        return todayCases;
    }

    public void setTodayCases(String todayCases) {
        this.todayCases = todayCases;
    }

    public String getDeaths() {
        return deaths;
    }

    public void setDeaths(String deaths) {
        this.deaths = deaths;
    }

    public String getTodaydeaths() {
        return todaydeaths;
    }

    public void setTodaydeaths(String todaydeaths) {
        this.todaydeaths = todaydeaths;
    }

    public String getRecoveredcases() {
        return recoveredcases;
    }

    public void setRecoveredcases(String recoveredcases) {
        this.recoveredcases = recoveredcases;
    }

    public String getActivecases() {
        return activecases;
    }

    public void setActivecases(String activecases) {
        this.activecases = activecases;
    }

    public String getCriticalcases() {
        return criticalcases;
    }

    public void setCriticalcases(String criticalcases) {
        this.criticalcases = criticalcases;
    }
}
